# XSLTTransformerGridData
Used to transform data from one to many Simio data table(s) into another Simo data table.   Only works with Simio 15.249 or higher.
