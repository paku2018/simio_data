# PostgreSQLGridData
Import and Export Data Connector for PostgreSQL.

To install, download all the files contained in the Executables folder.

Once downloaded, right-click on each file and select properties.   From the properties dialog, choose the "Unblock" option and press "Apply".

Then, please the files into a folded named "SimioUserExtensions" in your Documents folder.   When Simio load, it will find the allociated files in this folder.

If installed correct, you will find a PostgreSQL Data Importer and PostgreSQL Data Exporter from the Data Connector menu.

In the Models folder, you will find a quick example that uses both the PostgreSQL Data Importer and PostgreSQL Data Exporter.
