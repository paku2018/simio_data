The latest compiled version of this add-in requires Simio Sprint 278 or later.
