You can move these files to someplace where Simio picks them up (e.g. your Documents > SimioUserExtensions)
and then they will be added to your Simio model (as Add-In).