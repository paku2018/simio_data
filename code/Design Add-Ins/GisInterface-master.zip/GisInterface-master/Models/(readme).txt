This folder contains a sample project that was created by the GisInterface AddIn.
You can load it and run it to see the GIS route chosen.