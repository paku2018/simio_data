# SdxHarness
This software facilitates the creation of Simio objects in the Simio Design window by creating a common Open SDX (Simio Data Exchange)  XML file.
This dataset can be imported into Simio desktop's Facility view using an AddIn (such as the Visio AddIn).

