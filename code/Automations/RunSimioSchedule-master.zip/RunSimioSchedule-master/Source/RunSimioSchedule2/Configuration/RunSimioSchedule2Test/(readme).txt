This entire folder and contents of RunSimioSchedule2Test should be copied to a root folder.
The default in the project settings for this root folder is c:\temp\

Then you can run by moving a project (such as HospitalEmergencyDepartment.spfx) into the "In" folder so that the RunSimioSchedule2 program will find it and begin processing.
