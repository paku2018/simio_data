# RunSimioPortalExpConsole
Demonstrates the running of Plans, Experiments and other SimioPortal Web API methods using a Windows Console Application.    

See Documentation folder for more details.
