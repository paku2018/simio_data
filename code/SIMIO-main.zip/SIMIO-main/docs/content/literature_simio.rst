
Published Papers that used SIMIO
================================

1) `Pinilla et al. (2022) <https://ui.adsabs.harvard.edu/abs/2022arXiv220609975P/abstract>`_: Distributions of gas and small and large grains in the LkHa 330 disk trace a young planetary system.

2) `Garrido-Deutelmoser et al. (2023) <https://ui.adsabs.harvard.edu/abs/2023ApJ...945L..37G/abstract>`_: A Gap-sharing Planet Pair Shaping the Crescent in HD 163296: A Disk Sculpted by a Resonant Chain.

3) `Gárate et al. (2023) <https://ui.adsabs.harvard.edu/abs/2023arXiv230908752G/abstract>`_:  Millimeter emission in photoevaporating disks is determined by early substructures.
