# AVEVAMES
AVEVA MES Integration Templates

This project provides templates for the integration between Simio and AVEVA MES.  See the SimioProductionSchedulingAvevaMESInterface.docx under the Documents folder for more information.

