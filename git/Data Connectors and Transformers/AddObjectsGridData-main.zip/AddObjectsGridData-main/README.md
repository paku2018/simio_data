Data Transformer used to create objects bases on model control values.
